def exibir_menu():
    print("************")
    print("       CONTROLE FINANCEIRO        ")
    print("************")
    print("1 - Informar renda mensal")
    print("2 - Cadastrar gasto")
    print("3 - Consultar gastos")
    print("4 - Consultar situação financeira")
    print("5 - Ver estatísticas")
    print("6 - Sair")
    print("************")

def main():
    renda = 0.0
    gastos = []
    
    categorias = {
        1: "Alimentação",
        2: "Transporte",
        3: "Lazer",
        4: "Saúde",
        5: "Outros"
    }

    while True:
        exibir_menu()
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            try:
                renda = float(input("\nInforme a sua renda mensal (R$): "))
                print(f"Renda atualizada para R$ {renda:.2f}\n")
            except ValueError:
                print("Erro: Digite um valor numérico válido.\n")

        elif opcao == "2":
            descricao = input("\nDescrição do gasto (ex: Mercado): ")
            try:
                valor = float(input("Valor (R$): "))
            except ValueError:
                print("Erro: Valor inválido.\n")
                continue

            print("\nCategoria:")
            for chave, nome in categorias.items():
                print(f"{chave} - {nome}")
            
            try:
                cat_opcao = int(input("Escolha a categoria: "))
                categoria = categorias.get(cat_opcao, "Outros")
            except ValueError:
                categoria = "Outros"

            gastos.append({
                "descricao": descricao,
                "valor": valor,
                "categoria": categoria
            })
            print("Gasto cadastrado com sucesso!\n")

        elif opcao == "3":
            if not gastos:
                print("\nNenhum gasto cadastrado até ao momento.\n")
            else:
                print("\n--- LISTA DE GASTOS ---")
                for i, gasto in enumerate(gastos, 1):
                    print(f"{i}. {gasto['descricao']} | R$ {gasto['valor']:.2f} | Categoria: {gasto['categoria']}")
                print()

        elif opcao == "4":
            total_gastos = sum(g["valor"] for g in gastos)
            saldo = renda - total_gastos
            
            print("\n--- SITUAÇÃO FINANCEIRA ---")
            print(f"Renda Mensal: R$ {renda:.2f}")
            print(f"Total Gastos: R$ {total_gastos:.2f}")
            print(f"Saldo Restante: R$ {saldo:.2f}")
            
            if saldo >= 0:
                print("Situação: Dentro do orçamento!")
            else:
                print("Situação: Orçamento estourado (Défice)!")
            print()

        elif opcao == "5":
            if not gastos:
                print("\nNenhum gasto cadastrado para calcular estatísticas.\n")
            else:
                total_gastos = sum(g["valor"] for g in gastos)
                media_gastos = total_gastos / len(gastos)
                
                print("\n--- ESTATÍSTICAS ---")
                print(f"Quantidade total de gastos: {len(gastos)}")
                print(f"Total gasto no mês: R$ {total_gastos:.2f}")
                print(f"Média por gasto: R$ {media_gastos:.2f}")
                
                totais_por_categoria = {}
                for g in gastos:
                    cat = g["categoria"]
                    totais_por_categoria[cat] = totais_por_categoria.get(cat, 0.0) + g["valor"]
                
                print("\nGastos por Categoria:")
                for cat, val in totais_por_categoria.items():
                    percentual = (val / total_gastos) * 100 if total_gastos > 0 else 0
                    print(f" - {cat}: R$ {val:.2f} ({percentual:.1f}%)")
                print()

        elif opcao == "6":
            print("\nA encerrar o sistema... Até breve!")
            break

        else:
            print("Opção inválida! Escolha um número entre 1 e 6.\n")

if __name__ == "__main__":
    main()
